<?php

/** Non-secret publication manifest. Enable only after auditing the real Context build. */
return [
    'enabled' => false,
    'knowledge_base' => 'kbbBvrClyweF',
    'organization' => 'oatv1mmu8',
    'endpoint' => env('SANITY_COURSE_CONTEXT_ENDPOINT_NAME', env('SANITY_CONTEXT_ENDPOINT_NAME')),
    'token' => env('SANITY_COURSE_CONTEXT_VIEWER_TOKEN', env('SANITY_CONTEXT_VIEWER_TOKEN')),
    'revision_id' => null,
    'outline_sha256' => null,
    'sources' => [],
    'entries' => [],
];
