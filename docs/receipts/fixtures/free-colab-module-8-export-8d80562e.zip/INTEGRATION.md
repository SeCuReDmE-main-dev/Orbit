# Raccordement — module 8

- `src/learning/module-8/register-capabilities.js`

Ces fichiers proviennent de votre variable student_files; aucun corrigé ne remplace le code à l’export.
Conservez identifiants, coordonnées normalisées, dt en secondes et fonctions de nettoyage.
L’aperçu n’est pas une compilation Astro, un appel WebMCP réel ni une mesure de performance Three.js.
La remise reste sélectionnée par vous. Sanity ne reçoit rien de ce notebook.
Le notebook.ipynb exporté conserve le code et le bilan pour reprise, sans prétendre capturer l’exécution indépendante.

Transfert : Proposez une capacité de lecture bornée utile à votre propre projet, sans publication ni accès arbitraire.
