"""Execute only in Kaggle: software replay, not the real Colab picker or PDF render."""
from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'docs/learning/orbit-formation'


def module_from_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


notebook_tests = module_from_file('orbit_existing_notebook_test', ROOT / 'tests/learning-notebooks-test.py')
finalizer = module_from_file('orbit_review_finalizer', BASE / 'publication/scripts/finalize_document_review.py')
notebook = json.loads((BASE / 'notebooks/module-8.ipynb').read_text(encoding='utf-8'))


def cell(index):
    return ''.join(notebook['cells'][index]['source'])


def namespace(uploaded=None):
    values = dict(html=__import__('html'), hashlib=hashlib, io=io, json=json, zipfile=zipfile,
                  Path=Path, display=lambda value: None, HTML=lambda value: value)
    exec(cell(12), values)
    values['uploaded'] = dict(uploaded or {})
    with redirect_stdout(io.StringIO()):
        exec(cell(14), values)
    return values


class ImportWorkflowValidation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Declared synthetic exports exercise the actual export and merge code.
        cls.archives = {
            f'qa-module-{number}.zip': notebook_tests.exported(number, f'\n// QA-MODULE-{number}\n')[0]
            for number in range(1, 9)
        }

    def upload(self, values, upload):
        google = types.ModuleType('google')
        colab = types.ModuleType('google.colab')
        colab.files = types.SimpleNamespace(upload=upload, download=lambda name: None)
        google.colab = colab
        with patch.dict(sys.modules, {'google': google, 'google.colab': colab}), redirect_stdout(io.StringIO()) as output:
            exec(cell(13), values)
        return output.getvalue()

    def assemble(self, values, fingerprint=''):
        downloads = []
        values['files'] = types.SimpleNamespace(download=lambda name: downloads.append(name))
        source = cell(15).replace("ASSEMBLY_REVIEWED_SELECTION_SHA256 = ''",
                                  'ASSEMBLY_REVIEWED_SELECTION_SHA256 = ' + repr(fingerprint), 1)
        previous = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            try:
                os.chdir(directory)
                with redirect_stdout(io.StringIO()) as output:
                    exec(source, values)
                data = Path(downloads[0]).read_bytes() if downloads else None
            finally:
                os.chdir(previous)
        return downloads, data, output.getvalue()

    def test_cancel_invalidates_prior_selection_and_does_not_assemble(self):
        values = namespace(self.archives)
        old = values['examined_selection']['sha256']
        message = self.upload(values, lambda: {})
        self.assertIn('UPLOAD_CANCELLED', message)
        self.assertIsNone(values['examined_selection'])
        downloads, data, output = self.assemble(values, old)
        self.assertEqual(downloads, [])
        self.assertIsNone(data)
        self.assertIn('SELECTION_REQUIRED', output)

    def test_upload_error_is_unavailable_not_a_reported_user_cancellation(self):
        values = namespace()
        def unavailable():
            raise RuntimeError('Synthetic widget transport incident')
        message = self.upload(values, unavailable)
        self.assertIn('UPLOAD_UNAVAILABLE', message)
        self.assertNotIn('UPLOAD_CANCELLED', message)
        self.assertEqual(values['uploaded'], {})

    def test_selected_upload_requires_separate_examination(self):
        values = namespace()
        message = self.upload(values, lambda: dict(self.archives))
        self.assertIn('FILES_SELECTED_NOT_EXAMINED', message)
        self.assertIsNone(values['examined_selection'])
        self.assertEqual(values['uploaded'], self.archives)

    def test_wrong_count_and_duplicate_modules_are_refused(self):
        values = namespace()
        check = values['examine_selected_exports']
        with self.assertRaises(ValueError):
            check(dict(list(self.archives.items())[:7]))
        with self.assertRaises(ValueError):
            check({**self.archives, 'extra.zip': self.archives['qa-module-1.zip']})
        repeated = dict(self.archives)
        repeated['qa-module-8.zip'] = self.archives['qa-module-1.zip']
        with self.assertRaisesRegex(ValueError, 'Deux exports'):
            check(repeated)

    def test_tampered_frontend_is_refused_before_acknowledgement(self):
        selected = dict(self.archives)
        with zipfile.ZipFile(io.BytesIO(selected['qa-module-3.zip'])) as source:
            members = {info.filename: source.read(info) for info in source.infolist()}
        members['frontend/scene-controller.js'] += b'\n// changed after manifest'
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_STORED) as output:
            for name, data in members.items():
                output.writestr(name, data)
        selected['qa-module-3.zip'] = buffer.getvalue()
        values = namespace(selected)
        self.assertIsNone(values['examined_selection'])
        self.assertIsNone(values['project_data'])

    def test_exact_selection_is_examined_but_not_implicitly_assembled(self):
        values = namespace(self.archives)
        self.assertEqual([row['moduleId'] for row in values['examined_selection']['rows']], list(range(1, 9)))
        self.assertTrue(all(row['resultSchemaVersion'] == 'orbit-learning-colab-v1' for row in values['examined_selection']['rows']))
        self.assertTrue(all(row['manifestSchemaVersion'] == 'orbit-learning-artifact-bundle-v1' for row in values['examined_selection']['rows']))
        downloads, data, output = self.assemble(values)
        self.assertEqual(downloads, [])
        self.assertIsNone(data)
        self.assertIn('SELECTION_ACKNOWLEDGEMENT_REQUIRED', output)

    def test_acknowledged_selection_preserves_all_actual_modified_bricks(self):
        values = namespace(self.archives)
        fingerprint = values['examined_selection']['sha256']
        downloads, data, output = self.assemble(values, fingerprint)
        self.assertEqual(len(downloads), 1)
        self.assertIn('ASSEMBLED_NOT_BUILT', output)
        self.assertIn('"humanApproval": false', output)
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for number in range(1, 9):
                name = next(name for name in notebook_tests.merge.REQUIRED[number] if name.endswith('.js'))
                self.assertIn(f'QA-MODULE-{number}', archive.read(f'src/learning/module-{number}/{name}').decode('utf-8'))
            self.assertEqual(len(json.loads(archive.read('assembly-manifest.json'))['files']), 46)

    def test_changed_selection_cannot_use_an_earlier_examination(self):
        values = namespace(self.archives)
        fingerprint = values['examined_selection']['sha256']
        values['uploaded']['qa-module-3.zip'] = notebook_tests.exported(3, '\n// different selected version\n')[0]
        downloads, data, output = self.assemble(values, fingerprint)
        self.assertEqual(downloads, [])
        self.assertIsNone(data)
        self.assertIn('ASSEMBLY_REFUSED', output)


class PublicationReplayValidation(unittest.TestCase):
    def test_exact_book_paths_are_selected_independent_of_directory_contents(self):
        report = {'pdf': [{'path': 'outputs/book.pdf'}], 'docx': [{'path': 'outputs/book.docx'}]}
        self.assertEqual(finalizer.reviewed_output(report, 'pdf')['path'], 'outputs/book.pdf')
        self.assertEqual(finalizer.reviewed_output(report, 'docx')['path'], 'outputs/book.docx')
        for invalid in ({'pdf': [{'path': 'outputs/other.pdf'}]},
                        {'pdf': [{'path': 'outputs/book.pdf'}, {'path': 'outputs/other.pdf'}]}, {'pdf': []}):
            with self.assertRaises(ValueError):
                finalizer.reviewed_output(invalid, 'pdf')

    def test_refused_artifact_path_expires_old_distribution_inventory(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / 'qa').mkdir()
            (base / 'outputs').mkdir()
            (base / 'qa/final-publication-artifacts.json').write_text('{"state":"OLD_READY_FIXTURE"}')
            for name in ('source-review.json', 'export-report.json'):
                (base / 'qa' / name).write_text('{}')
            (base / 'qa/output-review.json').write_text(json.dumps({'pdf': [{'path': 'outputs/other.pdf'}], 'docx': [{'path': 'outputs/book.docx'}]}))
            (base / 'outputs/publication_qa.json').write_text('{}')
            with patch.object(finalizer, 'BASE', base), patch.object(sys, 'argv', ['finalize', '--visually-reviewed-pdf-sha256', '0' * 64]), redirect_stdout(io.StringIO()):
                code = finalizer.main()
            self.assertEqual(code, 2)
            self.assertFalse((base / 'qa/final-publication-artifacts.json').exists())
            report = json.loads((base / 'qa/document-delivery-review.json').read_text())
            self.assertFalse(report['documentReadyForAuthorReview'])
            self.assertFalse(report['deliveryReady'])

    def test_missing_input_also_expires_old_distribution_inventory(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / 'qa').mkdir()
            inventory = base / 'qa/final-publication-artifacts.json'
            inventory.write_text('{"state":"OLD_READY_FIXTURE"}')
            with patch.object(finalizer, 'BASE', base), patch.object(sys, 'argv', ['finalize', '--visually-reviewed-pdf-sha256', '0' * 64]):
                with self.assertRaises(FileNotFoundError):
                    finalizer.main()
            self.assertFalse(inventory.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
