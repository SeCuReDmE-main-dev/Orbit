<?php

use App\Http\Controllers\KnowledgeController;
use App\Http\Middleware\PublicCourseContext;
use Illuminate\Support\Facades\Route;

Route::middleware([PublicCourseContext::class, 'throttle:20,1'])->group(function (): void {
    Route::get('/v1/course-context/outline', [KnowledgeController::class, 'outline']);
    Route::get('/v1/course-context/entries', [KnowledgeController::class, 'entries']);
});
