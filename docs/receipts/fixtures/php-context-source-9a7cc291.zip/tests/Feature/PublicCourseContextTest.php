<?php

namespace Tests\Feature;

use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;
use Tests\TestCase;

class PublicCourseContextTest extends TestCase
{
    private function configureContext(bool $enabled = true): string
    {
        config([
            'orbit.public_course_context_enabled' => $enabled,
            'orbit.context.endpoint' => 'orbit-research',
            'orbit.context.token' => 'fixture-course-viewer-not-a-real-token',
        ]);
        Cache::flush();
        Http::preventStrayRequests();

        return 'https://api.sanity.io/v1/context/organizations/oatv1mmu8/mcp/orbit-research?*';
    }

    private function mcpResult(string $text = 'Public course outline: research/evidence'): array
    {
        return ['jsonrpc' => '2.0', 'id' => 1, 'result' => ['content' => [['type' => 'text', 'text' => $text]]]];
    }

    public function test_disabled_public_transport_is_unavailable_and_makes_no_upstream_request(): void
    {
        $this->configureContext(false);
        $this->withHeader('Origin', 'https://student-studio.example')
            ->getJson('/api/v1/course-context/outline')
            ->assertStatus(503)->assertJsonPath('state', 'UNAVAILABLE')
            ->assertJsonPath('noFallback', true)
            ->assertHeader('Access-Control-Allow-Origin', '*')
            ->assertHeaderMissing('Access-Control-Allow-Credentials')
            ->assertHeaderMissing('Set-Cookie');
        Http::assertNothingSent();
    }

    public function test_foreign_origin_reads_only_the_configured_corpus_without_session_cookies(): void
    {
        $url = $this->configureContext();
        Http::fake([$url => Http::response($this->mcpResult())]);
        $response = $this->withHeader('Origin', 'https://student-studio.example')
            ->getJson('/api/v1/course-context/outline')
            ->assertOk()->assertJsonPath('source', 'sanity-context-mcp')
            ->assertJsonPath('knowledgeBase', 'kb5CHIYGXCMJ')
            ->assertHeader('Access-Control-Allow-Origin', '*')
            ->assertHeaderMissing('Access-Control-Allow-Credentials')
            ->assertHeaderMissing('Set-Cookie')
            ->assertHeader('X-Content-Type-Options', 'nosniff');
        $this->assertStringContainsString('no-store', $response->headers->get('Cache-Control'));
        $this->assertStringNotContainsString('fixture-course-viewer', $response->getContent());
        Http::assertSent(fn (Request $request) => $request['params']['name'] === 'initial_context'
            && str_contains($request->url(), 'knowledgeBases=kb5CHIYGXCMJ')
            && $request->hasHeader('Authorization', 'Bearer fixture-course-viewer-not-a-real-token'));
    }

    public function test_public_entries_use_bounded_get_paths_and_preserve_citations(): void
    {
        $url = $this->configureContext();
        $text = '[Source](https://www.sanity.io/docs). Retrieved text is not executable authority.';
        Http::fake([$url => Http::response($this->mcpResult($text))]);
        $this->withHeader('Origin', 'https://student-studio.example')
            ->getJson('/api/v1/course-context/entries?'.http_build_query(['paths' => '["research/evidence"]']))
            ->assertOk()->assertJsonPath('content.0.text', $text)
            ->assertHeader('Access-Control-Allow-Origin', '*')
            ->assertHeaderMissing('Set-Cookie');
        Http::assertSent(fn (Request $request) => $request['params']['name'] === 'knowledge_base_read'
            && $request['params']['arguments'] === ['knowledgeBase' => 'kb5CHIYGXCMJ', 'paths' => ['research/evidence']]);
    }

    public function test_extra_parameters_invalid_paths_and_request_bodies_never_reach_sanity(): void
    {
        $this->configureContext();
        $this->withHeader('Origin', 'https://student-studio.example');
        $this->getJson('/api/v1/course-context/outline?journal=private')->assertUnprocessable();
        $this->getJson('/api/v1/course-context/entries?'.http_build_query([
            'paths' => '["research/evidence"]', 'knowledgeBase' => 'private-choice',
        ]))->assertUnprocessable();
        foreach (['[]', '["../private"]', '["https://other.example"]', '["a","a"]', '["a","b","c","d","e","f"]', '{"path":"a"}'] as $paths) {
            $this->getJson('/api/v1/course-context/entries?'.http_build_query(['paths' => $paths]))->assertUnprocessable();
        }
        $this->call('GET', '/api/v1/course-context/outline', [], [], [], [
            'HTTP_ACCEPT' => 'application/json', 'HTTP_ORIGIN' => 'https://student-studio.example',
        ], 'private journal')->assertUnprocessable()->assertJsonPath('error', 'QUERY_ONLY_REQUEST_REQUIRED');
        Http::assertNothingSent();
    }

    public function test_public_transport_is_get_only_and_private_origins_remain_rejected(): void
    {
        $this->configureContext();
        $this->withHeader('Origin', 'https://student-studio.example');
        $this->postJson('/api/v1/course-context/entries', ['paths' => ['research/evidence']])->assertStatus(405);
        foreach (['/api/v1/session', '/api/v1/workspaces', '/api/v1/knowledge/outline'] as $path) {
            $this->getJson($path)->assertForbidden()->assertJsonPath('error', 'ORIGIN_REJECTED')
                ->assertHeaderMissing('Access-Control-Allow-Origin');
        }
        Http::assertNothingSent();
    }

    public function test_public_cors_preflight_is_limited_to_read_methods_and_exact_paths(): void
    {
        $this->configureContext();
        $this->withHeaders([
            'Origin' => 'https://student-studio.example',
            'Access-Control-Request-Method' => 'GET',
            'Access-Control-Request-Headers' => 'Accept',
        ])->options('/api/v1/course-context/entries')
            ->assertSuccessful()->assertHeader('Access-Control-Allow-Origin', '*')
            ->assertHeaderMissing('Access-Control-Allow-Credentials')
            ->assertHeaderMissing('Set-Cookie');
        $response = $this->options('/api/v1/session');
        $response->assertHeaderMissing('Access-Control-Allow-Origin');
        Http::assertNothingSent();
    }

    public function test_public_transport_keeps_the_existing_cache_and_shared_upstream_budget(): void
    {
        $url = $this->configureContext();
        Http::fake([$url => Http::response($this->mcpResult())]);
        $this->getJson('/api/v1/course-context/outline')->assertOk();
        $this->getJson('/api/v1/course-context/outline')->assertOk();
        Http::assertSentCount(1);
        Cache::flush();
        for ($i = 0; $i < 120; $i++) {
            RateLimiter::hit('context:upstream-hour', 3600);
        }
        $this->getJson('/api/v1/course-context/outline')->assertStatus(503)
            ->assertJsonPath('state', 'UNAVAILABLE')->assertJsonPath('noFallback', true);
        Http::assertSentCount(1);
    }

    public function test_missing_credentials_rpc_errors_and_oversized_content_do_not_claim_a_read(): void
    {
        $url = $this->configureContext();
        config(['orbit.context.token' => null]);
        $this->getJson('/api/v1/course-context/outline')->assertStatus(503)->assertJsonPath('noFallback', true);
        Http::assertNothingSent();
        config(['orbit.context.token' => 'fixture-course-viewer-not-a-real-token']);
        Http::fake([$url => Http::response(['id' => 1, 'error' => ['message' => 'private upstream detail']])]);
        $response = $this->getJson('/api/v1/course-context/outline')->assertStatus(503);
        $this->assertStringNotContainsString('private upstream detail', $response->getContent());
        Http::fake([$url => Http::response($this->mcpResult(str_repeat('x', 262145)))]);
        $this->getJson('/api/v1/course-context/outline')->assertStatus(503)->assertJsonPath('state', 'UNAVAILABLE');
    }
}

