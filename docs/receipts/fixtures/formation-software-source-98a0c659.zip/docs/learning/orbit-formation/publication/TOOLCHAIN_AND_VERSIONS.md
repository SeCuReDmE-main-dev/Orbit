# Versions et outils du dossier pédagogique

Point documentaire du **1er octobre 2026**. Les versions ci-dessous viennent des sources et reçus sélectionnés. Cette lecture prépare le dossier ; les exécutions du cours et les exports DOCX/PDF conservent leurs étapes et reçus distincts.

| Élément | Version / identité | Origine et qualification |
|---|---|---|
| Formation | `orbit-course-1.0.0` | Contrat et métadonnées des sources pédagogiques |
| Plugin portable | `@orbit/learning-studio` · `1.0.0` | Version déclarée dans son package ; distinguer chaque archive par SHA-256 |
| Registre pédagogique | 15 noms de recherche + 10 noms pédagogiques | Factory partagée ; enregistrement natif lié au document et au propriétaire du montage |
| Capacité du projet élève | `student_get_learning_snapshot` | Capacité bornée de la brique du Module 8 ; registre distinct des 25 outils d'Orbit |
| Moteurs | `baseline`, `n`, `p` | Sélection explicite, versions et résultats conservés séparément ; qualification d'une campagne de modèles distincte |
| Node | `22.20.0` | Observé dans les reçus Kaggle de build du vrai assemblage et de l'installation statique du plugin |
| Astro | `7.3.3` | Observé dans le build Kaggle du vrai assemblage ; le site déclare une plage `^7.3.3` |
| Three.js | `0.181.2` | Version figée du notebook et du squelette ; observée dans le build de l'assemblage |
| Sanity Studio | `6.16.0` | Dépendance figée du second hôte et reçus statiques Kaggle ; session authentifiée à qualifier séparément |
| React / React DOM | `19.3.0` | Dépendances figées du second hôte et reçus statiques Kaggle |
| styled-components | `6.5.3` | Dépendance figée du second hôte et reçus statiques Kaggle |
| esbuild | `0.28.2` | Version déclarée par le package portable ; sa déclaration seule ne prouve pas un build |
| Transport du corpus | GET `/api/v1/course-context/outline` et `/api/v1/course-context/entries` | Source actuelle, credentials navigateur omis, activation serveur explicite ; disponibilité et CORS attendent leur reçu |
| Pandoc | `3.9.0.2` | Version relevée dans le précontrôle du coordinateur à `2026-10-01T11:40:53Z` ; exports de cette édition encore à exécuter |
| XeLaTeX | MiKTeX-XeTeX `4.16`, MiKTeX `25.12` | Version relevée dans le même précontrôle ; compilation PDF et revue visuelle encore à effectuer |
| Polices de lecture | Arial et Consolas | Fichiers installés observés ; couverture des glyphes, rendu et lisibilité à examiner lors de l'export |
| Canva | Prototype et briefs préparés | Production des neuf documents web par le coordinateur après la qualification technique ; aucun rendu déclaré dans ce dossier |

Les versions d'outils d'export sont des relevés du précontrôle conservé, pas une nouvelle mesure de cette composition. Les chemins des exécutables et comptes restent dans le périmètre opérationnel privé. Les rapports publics retiennent nom, version, origine et portée.

Références de preuve : [qualification maintenue](QUALIFICATION.md), [build du véritable assemblage](../../../receipts/formation/actual-export-assembly.json), [installation portable figée historique](../../../receipts/formation/portable-studio-locked-install-kaggle.json), [archive portable f2 et graphe verrouillé](../../../receipts/formation/portable-studio-v2-install-kaggle.json), [141 assertions du payload courant](../../../receipts/formation/software-141-kaggle.json) et [retest indépendant corrigé du Module 4](../../../receipts/formation/free-colab-module-4-independent-retest.json). Les documents finis recevront leurs empreintes et leur rapport de rendu après le signal de production.
